static unsigned long ticks = 0;

void timer_handler() {
    ticks++;
}
