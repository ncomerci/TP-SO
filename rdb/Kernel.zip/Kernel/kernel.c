#include <stdint.h>
#include <string.h>
#include <lib.h>
#include <moduleLoader.h>
#include <naiveConsole.h>

#define LAST_KEY 0x50

extern uint8_t text;
extern uint8_t rodata;
extern uint8_t data;
extern uint8_t bss;
extern uint8_t endOfKernelBinary;
extern uint8_t endOfKernel;

static const uint64_t PageSize = 0x1000;

static void * const sampleCodeModuleAddress = (void*)0x400000;
static void * const sampleDataModuleAddress = (void*)0x500000;

typedef int (*EntryPoint)();

typedef struct time_struct {
	int hours;
	int minutes;
	int seconds;
} time_struct;

int kb_mapping[LAST_KEY] = {0};
int kb_mapping_ready = 0;

void clearBSS(void * bssAddress, uint64_t bssSize)
{
	memset(bssAddress, 0, bssSize);
}

void * getStackBase()
{
	return (void*)(
		(uint64_t)&endOfKernel
		+ PageSize * 8				//The size of the stack itself, 32KiB
		- sizeof(uint64_t)			//Begin at the top of the stack
	);
}

void * initializeKernelBinary()
{
	char buffer[10];

	ncPrint("[x64BareBones]");
	ncNewline();

	ncPrint("CPU Vendor:");
	ncPrint(cpuVendor(buffer));
	ncNewline();

	ncPrint("[Loading modules]");
	ncNewline();
	void * moduleAddresses[] = {
		sampleCodeModuleAddress,
		sampleDataModuleAddress
	};

	loadModules(&endOfKernelBinary, moduleAddresses);
	ncPrint("[Done]");
	ncNewline();
	ncNewline();

	ncPrint("[Initializing kernel's binary]");
	ncNewline();

	clearBSS(&bss, &endOfKernel - &bss);

	ncPrint("  text: 0x");
	ncPrintHex((uint64_t)&text);
	ncNewline();
	ncPrint("  rodata: 0x");
	ncPrintHex((uint64_t)&rodata);
	ncNewline();
	ncPrint("  data: 0x");
	ncPrintHex((uint64_t)&data);
	ncNewline();
	ncPrint("  bss: 0x");
	ncPrintHex((uint64_t)&bss);
	ncNewline();

	ncPrint("[Done]");
	ncNewline();
	ncNewline();
	return getStackBase();
}

time_struct get_time() {
	time_struct ans;

	uint8_t aux = getRTC(4);
	ans.hours = (aux/16 * 10) + (aux % 16);
	if (ans.hours <= 2)  //Adjusting local hour
		ans.hours = 21 + ans.hours;
	else
		ans.hours -= 3;
	aux = getRTC(2);
	ans.minutes = (aux/16 * 10) + (aux % 16);
	aux = getRTC(0);
	ans.seconds = (aux/16 * 10) + (aux % 16);

	return ans;
}

// Maybe we should make a second array for shift calls
void _init_kb_mapping() {

	// Mapping numbers
	for (int i = 1; i < 10; i++) {
		kb_mapping[0x01 + i] = 0x30 + i;
	}
	kb_mapping[0x0B] = '0';

	// Mapping letters

	// First Row
	kb_mapping[0x10] = 'q';
	kb_mapping[0x11] = 'w';
	kb_mapping[0x12] = 'e';
	kb_mapping[0x13] = 'r';
	kb_mapping[0x14] = 't';
	kb_mapping[0x15] = 'y';
	kb_mapping[0x16] = 'u';
	kb_mapping[0x17] = 'i';
	kb_mapping[0x18] = 'o';
	kb_mapping[0x19] = 'p';

	// Second Row
	kb_mapping[0x1E] = 'a';
	kb_mapping[0x1F] = 's';
	kb_mapping[0x20] = 'd';
	kb_mapping[0x21] = 'f';
	kb_mapping[0x22] = 'g';
	kb_mapping[0x23] = 'h';
	kb_mapping[0x24] = 'j';
	kb_mapping[0x25] = 'k';
	kb_mapping[0x26] = 'l';

	// Third Row
	kb_mapping[0x2C] = 'z';
	kb_mapping[0x2D] = 'x';
	kb_mapping[0x2E] = 'c';
	kb_mapping[0x2F] = 'v';
	kb_mapping[0x30] = 'b';
	kb_mapping[0x31] = 'n';
	kb_mapping[0x32] = 'm';


}

int getASCII(int hex) {
	if (!kb_mapping_ready) {
		_init_kb_mapping();
		kb_mapping_ready = 1;
	}
	return kb_mapping[hex];
}

void waitKeyboard() {

	int teclahex, teclahexant;

	int amount = 1;
	int mayus = 0;

	ncClear();

	ncNewline();
	ncPrint("Esperando tecla ...");
	teclahexant = teclahex = kbFlag();
	ncNewline();
	if (teclahex == 0x2A || teclahex == 0x36) // Si es el LEFT SHIFT o el RIGHT SHIFT
		mayus = 1;
	else {
		ncPrint("Tecla recibida: ");
		ncPrintChar(getASCII(teclahex));
		ncNewline();
		ncNewline();
		ncPrint("Esperando tecla ...");
		ncNewline();
	}

	while (1) {
		teclahex = kbFlag();
		if (teclahex == 0x2A || teclahex == 0x36) // Si es el LEFT SHIFT o el RIGHT SHIFT
			mayus = 1;
		else if (teclahex == 0x2A + 0x80 || teclahex == 0x36 + 0x80) // Si se soltó el shift
			mayus = 0;
		else if (teclahex != teclahexant) {
			amount++;
			if (amount % 7 == 0)
				ncClear();
			if (teclahex == teclahexant + 8 * 16) {
				ncPrint("Tecla liberada: ");
				if (!mayus)
					ncPrintChar(getASCII(teclahexant));
				else if (getASCII(teclahexant))
					ncPrintChar(getASCII(teclahexant) - 0x20);
			}
			else {
				ncPrint("Tecla presionada: ");
				if (!mayus)
					ncPrintChar(getASCII(teclahex));
				else if (getASCII(teclahex))
					ncPrintChar(getASCII(teclahex) - 0x20);
			}
			ncNewline();
			ncNewline();
			ncPrint("Esperando tecla ...");
			ncNewline();
			teclahexant = teclahex;
		}
	}
}



int main()
{
	ncPrint("[Kernel Main]");
	ncNewline();
	ncPrint("  Sample code module at 0x");
	ncPrintHex((uint64_t)sampleCodeModuleAddress);
	ncNewline();
	ncPrint("  Calling the sample code module returned: ");
	ncPrintHex(((EntryPoint)sampleCodeModuleAddress)());
	ncNewline();
	ncNewline();

	ncPrint("  Sample data module at 0x");
	ncPrintHex((uint64_t)sampleDataModuleAddress);
	ncNewline();
	ncPrint("  Sample data module contents: ");
	ncPrint((char*)sampleDataModuleAddress);
	ncNewline();

	ncPrint("[Finished]");
	ncNewline();

	time_struct time = get_time();

	ncPrint("Local time is:");
	ncNewline();
	ncPrintDec(time.hours);
	ncPrint(" h ");
	ncPrintDec(time.minutes);
	ncPrint(" m ");
	ncPrintDec(time.seconds);
	ncPrint(" s");
	ncNewline();

//	waitKeyboard();


	//load_idt();

	return 0;
}
