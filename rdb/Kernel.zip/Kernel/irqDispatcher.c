#include <interrupts.h>

void irqDispatcher(uint64_t irq) {
    switch (irq) {
        case 0:
          int_20(); //timer tick
          break;
        }
        return;
    }

void int_20() {
    timer_handler();
}
