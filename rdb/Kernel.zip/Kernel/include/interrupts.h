#ifndef INTERRUPTS_H
#define INTERRUPTS_H

#include <stdint.h>

void timer_handler();
void _irq00Handler();
void int_20();

void irqDispatcher(uint64_t irq);
void _cli();
void _sti();
void picSlaveMask(uint8_t mask);
void picMasterMask(uint8_t mask);

#endif
